package io.github.neczpal.generated.server;

import java.lang.Integer;
import java.lang.String;
import java.lang.Void;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/pet")
public interface PetApi {
    /**
     * Update an existing pet
     *
     * Update an existing pet by Id
     *
     * Possible error codes:
     * - 400
     * - 404
     * - 422
     */
    @PutMapping("")
    ResponseEntity<Pet> updatePet(@RequestBody Pet body);

    /**
     * Add a new pet to the store
     *
     * Add a new pet to the store
     *
     * Possible error codes:
     * - 400
     * - 422
     */
    @PostMapping("")
    ResponseEntity<Pet> addPet(@RequestBody Pet body);

    /**
     * Finds Pets by status
     *
     * Multiple status values can be provided with comma separated strings
     *
     * Possible error codes:
     * - 400
     */
    @GetMapping("/findByStatus")
    ResponseEntity<List<Pet>> findPetsByStatus(@RequestParam("status") String status);

    /**
     * Finds Pets by tags
     *
     * Multiple tags can be provided with comma separated strings. Use tag1, tag2, tag3 for testing.
     *
     * Possible error codes:
     * - 400
     */
    @GetMapping("/findByTags")
    ResponseEntity<List<Pet>> findPetsByTags(@RequestParam("tags") List<String> tags);

    /**
     * Find pet by ID
     *
     * Returns a single pet
     *
     * Possible error codes:
     * - 400
     * - 404
     */
    @GetMapping("/{petId}")
    ResponseEntity<Pet> getPetById(@PathVariable("petId") Integer petId);

    /**
     * Updates a pet in the store with form data
     *
     *
     *
     * Possible error codes:
     * - 400
     */
    @PostMapping("/{petId}")
    ResponseEntity<Pet> updatePetWithForm(@PathVariable("petId") Integer petId,
            @RequestParam("name") String name, @RequestParam("status") String status);

    /**
     * Deletes a pet
     *
     *
     *
     * Possible error codes:
     * - 400
     */
    @DeleteMapping("/{petId}")
    ResponseEntity<Void> deletePet(@PathVariable("petId") Integer petId);

    /**
     * uploads an image
     *
     *
     *
     * Possible error codes:
     * - 400
     * - 404
     */
    @PostMapping("/{petId}/uploadImage")
    ResponseEntity<ApiResponse> uploadFile(@PathVariable("petId") Integer petId,
            @RequestParam("additionalMetadata") String additionalMetadata,
            @RequestBody String body);
}
