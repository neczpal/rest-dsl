package io.github.neczpal.generated.server;

import java.lang.Integer;
import java.lang.String;
import java.lang.Void;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/store")
public interface StoreApi {
    /**
     * Returns pet inventories by status
     *
     * Returns a map of status codes to quantities
     */
    @GetMapping("/inventory")
    ResponseEntity<String> getInventory();

    /**
     * Place an order for a pet
     *
     * Place a new order in the store
     *
     * Possible error codes:
     * - 400
     * - 422
     */
    @PostMapping("/order")
    ResponseEntity<Order> placeOrder(@RequestBody Order body);

    /**
     * Find purchase order by ID
     *
     * For valid response try integer IDs with value <= 5 or > 10. Other values will generate exceptions.
     *
     * Possible error codes:
     * - 400
     * - 404
     */
    @GetMapping("/order/{orderId}")
    ResponseEntity<Order> getOrderById(@PathVariable("orderId") Integer orderId);

    /**
     * Delete purchase order by ID
     *
     * For valid response try integer IDs with value < 1000. Anything above 1000 or nonintegers will generate API errors
     *
     * Possible error codes:
     * - 400
     * - 404
     */
    @DeleteMapping("/order/{orderId}")
    ResponseEntity<Void> deleteOrder(@PathVariable("orderId") Integer orderId);
}
