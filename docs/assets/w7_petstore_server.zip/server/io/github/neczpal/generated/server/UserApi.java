package io.github.neczpal.generated.server;

import java.lang.String;
import java.lang.Void;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public interface UserApi {
    /**
     * Create user
     *
     * This can only be done by the logged in user.
     */
    @PostMapping("")
    ResponseEntity<User> createUser(@RequestBody User body);

    /**
     * Creates list of users with given input array
     */
    @PostMapping("/createWithList")
    ResponseEntity<User> createUsersWithListInput(@RequestBody List<User> body);

    /**
     * Logs user into the system
     *
     * Possible error codes:
     * - 400
     */
    @GetMapping("/login")
    ResponseEntity<String> loginUser(@RequestParam("username") String username,
            @RequestParam("password") String password);

    /**
     * Logs out current logged in user session
     */
    @GetMapping("/logout")
    ResponseEntity<Void> logoutUser();

    /**
     * Get user by user name
     *
     * Possible error codes:
     * - 400
     * - 404
     */
    @GetMapping("/{username}")
    ResponseEntity<User> getUserByName(@PathVariable("username") String username);

    /**
     * Update user
     *
     * This can only be done by the logged in user.
     *
     * Possible error codes:
     * - 400
     * - 404
     */
    @PutMapping("/{username}")
    ResponseEntity<Void> updateUser(@PathVariable("username") String username,
            @RequestBody User body);

    /**
     * Delete user
     *
     * This can only be done by the logged in user.
     *
     * Possible error codes:
     * - 400
     * - 404
     */
    @DeleteMapping("/{username}")
    ResponseEntity<Void> deleteUser(@PathVariable("username") String username);
}
