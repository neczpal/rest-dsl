package io.github.neczpal.generated.server;

import java.lang.Integer;
import java.lang.String;
import java.util.List;

public record Pet(Integer id, String name, Category category, List<String> photoUrls,
        List<Tag> tags, String status) {
}
