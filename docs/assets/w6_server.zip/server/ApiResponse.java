package io.github.neczpal.generated.server;

import java.lang.Integer;
import java.lang.String;

public record ApiResponse(Integer code, String type, String message) {
}
