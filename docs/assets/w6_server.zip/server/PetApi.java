package io.github.neczpal.generated.server;

import java.lang.Integer;
import java.lang.String;
import java.lang.Void;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/pet")
public interface PetApi {
    @PostMapping("")
    ResponseEntity<Pet> post(@RequestBody Pet body);

    @PutMapping("")
    ResponseEntity<Pet> updatePet(@RequestBody Pet body);

    @GetMapping("/findByStatus")
    ResponseEntity<List<Pet>> getFindByStatus(@RequestParam("status") String status);

    @GetMapping("/{petId}")
    ResponseEntity<Pet> getByPetId(@PathVariable("petId") Integer petId);

    @DeleteMapping("/{petId}")
    ResponseEntity<Void> deleteByPetId(@PathVariable("petId") Integer petId);

    @PostMapping("/{petId}")
    ResponseEntity<Pet> updateWithForm(@PathVariable("petId") Integer petId,
            @RequestParam("name") String name, @RequestParam("status") String status);
}
