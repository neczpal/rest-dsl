package io.github.neczpal.generated.server;

import java.lang.Integer;
import java.lang.String;

public record Category(Integer id, String name) {
}
