package io.github.neczpal.generated.server;

import java.lang.Integer;
import java.lang.String;

public record Pet(Integer id, String name, Category category, String status) {
}
