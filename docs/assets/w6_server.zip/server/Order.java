package io.github.neczpal.generated.server;

import java.lang.Boolean;
import java.lang.Integer;

public record Order(Integer id, Integer petId, Integer quantity, Boolean complete) {
}
