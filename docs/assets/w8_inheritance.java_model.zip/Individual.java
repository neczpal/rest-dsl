package io.github.neczpal.restdsl.inheritance.server;

import java.lang.String;

public sealed interface Individual extends User permits BusinessIndividual {
  String firstName();

  String lastName();
}
