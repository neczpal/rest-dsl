package io.github.neczpal.restdsl.inheritance.server;

import java.lang.Integer;
import java.lang.String;

public record Gmbh(Integer id, String email, String companyName,
    String registrationNumber) implements Company {
}
