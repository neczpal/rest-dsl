package io.github.neczpal.restdsl.inheritance.server;

import java.lang.Integer;
import java.lang.String;

public record Ltd(Integer id, String email, String companyName, String registrationNumber,
    String country) implements Company {
}
