package io.github.neczpal.restdsl.inheritance.server;

import java.lang.Integer;
import java.lang.String;

public sealed interface User permits Company, Individual {
  Integer id();

  String email();
}
