package io.github.neczpal.restdsl.inheritance.server;

import java.lang.String;

public sealed interface Company extends User permits Gmbh, Ltd {
  String companyName();
}
