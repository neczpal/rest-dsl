package io.github.neczpal.restdsl.inheritance.server;

import java.lang.Integer;
import java.lang.String;

public record BusinessIndividual(Integer id, String email, String firstName, String lastName,
    String taxNumber) implements Individual {
}
