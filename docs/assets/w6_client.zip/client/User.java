package io.github.neczpal.generated.client;

import java.lang.Integer;
import java.lang.String;

public record User(Integer id, String username, String email, String firstName, String lastName,
        String password, String phone, Integer userStatus) {
}
