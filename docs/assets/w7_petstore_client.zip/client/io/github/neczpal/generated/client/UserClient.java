package io.github.neczpal.generated.client;

import java.lang.String;
import java.util.List;
import org.springframework.web.client.RestClient;

public class UserClient {
    private final RestClient restClient;

    public UserClient(String baseUrl) {
        this.restClient = RestClient.builder().baseUrl(baseUrl).build();
    }

    /**
     * Create user
     *
     * This can only be done by the logged in user.
     */
    public User createUser(User body) {
        return restClient.post()
                                .body(body)
                                .retrieve()
                                .body(User.class);
    }

    /**
     * Creates list of users with given input array
     */
    public User createUsersWithListInput(List<User> body) {
        return restClient.post()
                                .uri("/createWithList")
                                .body(body)
                                .retrieve()
                                .body(User.class);
    }

    /**
     * Logs user into the system
     *
     * Possible error codes:
     * - 400
     */
    public String loginUser(String username, String password) {
        return restClient.get()
                                .uri("/login?username={username}&password={password}", username, password)
                                .retrieve()
                                .body(String.class);
    }

    /**
     * Logs out current logged in user session
     */
    public void logoutUser() {
        restClient.get()
                                .uri("/logout")
                                .retrieve()
                                .toBodilessEntity();
    }

    /**
     * Get user by user name
     *
     * Possible error codes:
     * - 400
     * - 404
     */
    public User getUserByName(String username) {
        return restClient.get()
                                .uri("/{username}", username)
                                .retrieve()
                                .body(User.class);
    }

    /**
     * Update user
     *
     * This can only be done by the logged in user.
     *
     * Possible error codes:
     * - 400
     * - 404
     */
    public void updateUser(String username, User body) {
        restClient.put()
                                .uri("/{username}", username)
                                .body(body)
                                .retrieve()
                                .toBodilessEntity();
    }

    /**
     * Delete user
     *
     * This can only be done by the logged in user.
     *
     * Possible error codes:
     * - 400
     * - 404
     */
    public void deleteUser(String username) {
        restClient.delete()
                                .uri("/{username}", username)
                                .retrieve()
                                .toBodilessEntity();
    }
}
