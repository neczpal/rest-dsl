package io.github.neczpal.generated.client;

import java.lang.Integer;
import java.lang.String;
import java.util.List;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.web.client.RestClient;

public class PetClient {
    private final RestClient restClient;

    public PetClient(String baseUrl) {
        this.restClient = RestClient.builder().baseUrl(baseUrl).build();
    }

    /**
     * Update an existing pet
     *
     * Update an existing pet by Id
     *
     * Possible error codes:
     * - 400
     * - 404
     * - 422
     */
    public Pet updatePet(Pet body) {
        return restClient.put()
                                .body(body)
                                .retrieve()
                                .body(Pet.class);
    }

    /**
     * Add a new pet to the store
     *
     * Add a new pet to the store
     *
     * Possible error codes:
     * - 400
     * - 422
     */
    public Pet addPet(Pet body) {
        return restClient.post()
                                .body(body)
                                .retrieve()
                                .body(Pet.class);
    }

    /**
     * Finds Pets by status
     *
     * Multiple status values can be provided with comma separated strings
     *
     * Possible error codes:
     * - 400
     */
    public List<Pet> findPetsByStatus(String status) {
        return restClient.get()
                                .uri("/findByStatus?status={status}", status)
                                .retrieve()
                                .body(new ParameterizedTypeReference<List<Pet>>() {});
    }

    /**
     * Finds Pets by tags
     *
     * Multiple tags can be provided with comma separated strings. Use tag1, tag2, tag3 for testing.
     *
     * Possible error codes:
     * - 400
     */
    public List<Pet> findPetsByTags(List<String> tags) {
        return restClient.get()
                                .uri("/findByTags?tags={tags}", tags)
                                .retrieve()
                                .body(new ParameterizedTypeReference<List<Pet>>() {});
    }

    /**
     * Find pet by ID
     *
     * Returns a single pet
     *
     * Possible error codes:
     * - 400
     * - 404
     */
    public Pet getPetById(Integer petId) {
        return restClient.get()
                                .uri("/{petId}", petId)
                                .retrieve()
                                .body(Pet.class);
    }

    /**
     * Updates a pet in the store with form data
     *
     *
     *
     * Possible error codes:
     * - 400
     */
    public Pet updatePetWithForm(Integer petId, String name, String status) {
        return restClient.post()
                                .uri("/{petId}?name={name}&status={status}", petId, name, status)
                                .retrieve()
                                .body(Pet.class);
    }

    /**
     * Deletes a pet
     *
     *
     *
     * Possible error codes:
     * - 400
     */
    public void deletePet(Integer petId) {
        restClient.delete()
                                .uri("/{petId}", petId)
                                .retrieve()
                                .toBodilessEntity();
    }

    /**
     * uploads an image
     *
     *
     *
     * Possible error codes:
     * - 400
     * - 404
     */
    public ApiResponse uploadFile(Integer petId, String additionalMetadata, String body) {
        return restClient.post()
                                .uri("/{petId}/uploadImage?additionalMetadata={additionalMetadata}", petId, additionalMetadata)
                                .body(body)
                                .retrieve()
                                .body(ApiResponse.class);
    }
}
