package io.github.neczpal.generated.client;

import java.lang.Integer;
import java.lang.String;
import org.springframework.web.client.RestClient;

public class StoreClient {
    private final RestClient restClient;

    public StoreClient(String baseUrl) {
        this.restClient = RestClient.builder().baseUrl(baseUrl).build();
    }

    /**
     * Returns pet inventories by status
     *
     * Returns a map of status codes to quantities
     */
    public String getInventory() {
        return restClient.get()
                                .uri("/inventory")
                                .retrieve()
                                .body(String.class);
    }

    /**
     * Place an order for a pet
     *
     * Place a new order in the store
     *
     * Possible error codes:
     * - 400
     * - 422
     */
    public Order placeOrder(Order body) {
        return restClient.post()
                                .uri("/order")
                                .body(body)
                                .retrieve()
                                .body(Order.class);
    }

    /**
     * Find purchase order by ID
     *
     * For valid response try integer IDs with value <= 5 or > 10. Other values will generate exceptions.
     *
     * Possible error codes:
     * - 400
     * - 404
     */
    public Order getOrderById(Integer orderId) {
        return restClient.get()
                                .uri("/order/{orderId}", orderId)
                                .retrieve()
                                .body(Order.class);
    }

    /**
     * Delete purchase order by ID
     *
     * For valid response try integer IDs with value < 1000. Anything above 1000 or nonintegers will generate API errors
     *
     * Possible error codes:
     * - 400
     * - 404
     */
    public void deleteOrder(Integer orderId) {
        restClient.delete()
                                .uri("/order/{orderId}", orderId)
                                .retrieve()
                                .toBodilessEntity();
    }
}
