package io.github.neczpal.generated.client;

import java.lang.Boolean;
import java.lang.Integer;
import java.lang.String;

public record Order(Integer id, Integer petId, Integer quantity, String shipDate, String status,
        Boolean complete) {
}
