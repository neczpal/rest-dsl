package io.github.neczpal.generated.client;

import java.lang.Integer;
import java.lang.String;

public record Tag(Integer id, String name) {
}
