package io.github.neczpal.generated.client;

import java.lang.Integer;
import java.lang.String;

public record Pet(Integer id, String name, Category category, String status) {
}
