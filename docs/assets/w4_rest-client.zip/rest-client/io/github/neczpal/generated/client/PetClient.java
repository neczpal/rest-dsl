package io.github.neczpal.generated.client;

import java.lang.Integer;
import java.lang.String;
import java.util.List;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.web.client.RestClient;

public class PetClient {
  private final RestClient restClient;

  public PetClient(String baseUrl) {
    this.restClient = RestClient.builder().baseUrl(baseUrl).build();
  }

  public Pet addPet(Pet body) {
    return restClient.post()
                        .body(body)
                        .retrieve()
                        .body(Pet.class);
  }

  public Pet updatePet(Pet body) {
    return restClient.put()
                        .body(body)
                        .retrieve()
                        .body(Pet.class);
  }

  public Pet updatePetWithForm(Integer petId, String name, String status) {
    return restClient.post()
                        .uri("/{petId}?name={name}&status={status}", petId, name, status)
                        .retrieve()
                        .body(Pet.class);
  }

  public Pet getById(Integer petId) {
    return restClient.get()
                        .uri("/{petId}", petId)
                        .retrieve()
                        .body(Pet.class);
  }

  public List<Pet> findByStatus(String status) {
    return restClient.get()
                        .uri("/findByStatus?status={status}", status)
                        .retrieve()
                        .body(new ParameterizedTypeReference<List<Pet>>() {});
  }

  public void deletePet(Integer petId) {
    restClient.delete()
                        .uri("/{petId}", petId)
                        .retrieve()
                        .toBodilessEntity();
  }
}
