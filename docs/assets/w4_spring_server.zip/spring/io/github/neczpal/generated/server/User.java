package io.github.neczpal.generated.server;

import java.lang.Integer;
import java.lang.String;

public record User(Integer id, String username, String firstName, String lastName, String email,
    String password, String phone, Integer userStatus) {
}
